/* 
 * File:   StreamServer.cpp
 * Author: Alexandre Brandão Lustosa
 * 
 * Created on 4 de Março de 2014, 09:34
 */

/*
 *      O que acontce ser houver error no sevidor, gerar SIGTERM?
 *      Quais são as possíveis falhas do accept?
 */

#include "StreamServer.h"

template<class T>
bool StreamServer<T>::running = false;

template<class T>
StreamServer<T>::StreamServer(T *instance, unsigned int Port, unsigned int BufferSize, unsigned int MaxClients, bool useHeartBeat) {
    struct sockaddr_in serv_addr;
    int optval = 1;
    socklen_t optlen = sizeof (optval);

    printf("StreamServer Initializade. Port: %.4d\n", this->port);

    this->selfClass = instance;
    this->port = Port;
    this->bufferSize = BufferSize;
    this->maxClients = MaxClients;
    this->maxFd = 0;
    this->running = true;

    server = socket(AF_INET, SOCK_STREAM, 0);

    bzero((char *) &serv_addr, sizeof (serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(this->port);

    if (server < 0) {
        printf("StreamServer error opening server socket. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        exit(EXIT_FAILURE);
    }

    if (setsockopt(server, SOL_SOCKET, SO_KEEPALIVE, &optval, optlen) < 0) {
        printf("StreamServer error on set keep alive. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &optval, optlen) < 0) {
        printf("StreamServer error on set reuse address. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (fcntl(server, F_SETFL, O_NONBLOCK) < 0) {
        printf("StreamServer error on set non block option. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (fcntl(server, F_SETFL, O_ASYNC) < 0) {
        printf("StreamServer error on set async option. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (bind(server, (struct sockaddr *) &serv_addr, sizeof (serv_addr)) < 0) {
        printf("StreamServer error on bind. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (listen(server, this->maxClients) < 0) {
        printf("StreamServer error on listen. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }
    printf("StreamServer on listen. Port: %.4d\n", this->port);

    this->maxFd = this->server;
    FD_ZERO(&this->masterSet);
    FD_SET(this->server, &this->masterSet);

    signal (SIGPIPE, SIG_IGN);
    
    pthread_create(&thAcceptClients, NULL, &StreamServer<T>::AccpetClients, this);
    pthread_detach(thAcceptClients);

    if (useHeartBeat) {
        pthread_create(&thHeartBeat, NULL, &StreamServer<T>::HeartBeat, this);
        pthread_detach(thHeartBeat);
    }

    printf("StreamServer Created. Port: %.4d\n", this->port);
}

template<class T>
void* StreamServer<T>::AccpetClients(void* arg) {
    StreamServer<T> *self = (StreamServer<T>*)arg;

    self->AccpetClientsEvent(arg);
}

template<class T>
void StreamServer<T>::AccpetClientsEvent(void* arg) {
    StreamServer<T> *self = (StreamServer<T>*)arg;

    fd_set acceptSet;
    char buffer[self->bufferSize];

    memset(buffer, 0, self->bufferSize);

    printf("StreamServer on AccpetClients. Port: %.4d\n", self->port);

    self->acceptRunning = true;

    while (self->running == true) {
        memcpy(&acceptSet, &self->masterSet, sizeof (self->masterSet));

        printf("StreamServer wait on select. Port: %.4d\n", self->port);

        int selectFdCount = 0;

        selectFdCount = select(self->maxFd + 1, &acceptSet, NULL, NULL, NULL);
        
        if (selectFdCount < 0) {
            if (errno == EWOULDBLOCK) {
                printf("StreamServer EWOULDBLOCK on select. Port: %.4d\n", self->port);
                printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                continue;
            } else {
                if (errno == ENOTCONN) {
                    printf("StreamServer error on select, try again. Port: %.4d\n", self->port);
                    printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                    continue;
                } else {
                    printf("StreamServer error on select, server will close. Port: %.4d\n", self->port);
                    printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                    break;
                }
            }
        }

        if (selectFdCount == 0) {
            printf("StreamServer timeout on select. Port: %.4d\n", self->port);
            printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
            break;
        }

        printf("StreamServer selected succesfully. Port: %.4d, Select Result: %.4d\n", self->port, selectFdCount);

        for (unsigned int index = 0; index <= self->maxFd && selectFdCount > 0; index++) {
            if (FD_ISSET(index, &acceptSet)) {
                selectFdCount -= 1;

                if (index == self->server) {
                    printf("StreamServer ready for accept incoming connections. Port: %.4d\n", self->port);
                    int newClient = accept(self->server, NULL, NULL);
                    if (newClient < 0) {
                        if (errno != EWOULDBLOCK) {
                            printf("StreamServer error on accept. Port: %.4d\n", self->port);
                            printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                            self->running = false;
                            break;
                        }
                    } else {
                        FD_SET(newClient, &self->masterSet);
                        if (newClient > self->maxFd) self->maxFd = newClient;
                        printf("StreamServer client accepted. Port: %.4d, Client: %.4d\n", self->port, newClient);
                    }
                    printf("StreamServer end for accept incoming connections. Port: %.4d\n", self->port);
                } else {
                    if (self->running == true) {
                        int size = recv(index, buffer, self->bufferSize, 0);

                        if (size < 0) {
                            if (errno != EWOULDBLOCK) {
                                shutdown(index, SHUT_RDWR);
                                close(index);
                                FD_CLR(index, &self->masterSet);
                                printf("StreamServer Read error, client disconnected. Port: %.4d, Client: %.4d\n", self->port, index);
                                if (errno != 0) {
                                    printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                                }
                            }
                        } else {
                            if (size == 0) {
                                shutdown(index, SHUT_RDWR);
                                close(index);
                                FD_CLR(index, &self->masterSet);
                                printf("StreamServer Read client disconected. Port: %.4d, Client: %.4d\n", self->port, index);
                                printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                            } else {
                                printf("StreamServer received %.4d bytes. Port: %.4d, Client: %.4d\n", size, self->port, index);
#ifdef ECHO_TEST                                
                                self->Write(buffer, (unsigned int) size);
#endif                                
                                if(self->ptr != NULL){
                                    (selfClass->*ptr)(buffer, (unsigned int) size);
                                        printf("StreamServer OnReceiveNewData Event has sent %.4d bytes. Port: %.4d, Client: %.4d\n", size, self->port, index);
                                }else{
                                    printf("StreamServer OnReceiveNewData Event is NULL. Port: %.4d, Client: %.4d\n", self->port, index);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    printf("StreamServer Clossing All Connections. Port: %.4d\n", self->port);
    for (int index = 0; index <= self->maxFd; ++index) {
        if (FD_ISSET(index, &self->masterSet)) {
            shutdown(index, SHUT_RDWR);
            close(index);
            FD_CLR(index, &self->masterSet);
        }
    }

    printf("StreamServer Clossing Server. Port: %.4d\n", self->port);
    FD_CLR(self->server, &self->masterSet);
    shutdown(self->server, SHUT_RDWR);
    close(self->server);

    self->acceptRunning = false;

    printf("StreamServer AcceptClients End. Port: %.4d\n", self->port);

    exit(EXIT_FAILURE);
}

template<class T>
int StreamServer<T>::Write(char *buffer, unsigned int size) {
    printf("StreamServer Write Init. Port: %.4d\n", this->port);

    int written = 0;
    unsigned int tryAgain = 1;

    if (this->running) {

        this->writeRunning = true;

        for (int index = 0; index <= this->maxFd; ++index) {
            if (index != this->server) {
                if (FD_ISSET(index, &this->masterSet)) {
                    while ((tryAgain > 0) && (tryAgain <= 3)) {
                        int sendRes = send(index, buffer, size, MSG_NOSIGNAL);
                        if (sendRes > -1) {
                            tryAgain = 0;
                            printf("StreamServer Written %.4d bytes. Port: %.4d, Client: %.4d\n", size, this->port, index);
                            written = size;
                        } else {
                            if (errno != EWOULDBLOCK) {
                                shutdown(index, SHUT_RDWR);
                                close(index);
                                FD_CLR(index, &this->masterSet);
                                tryAgain = 0;
                                printf("StreamServer Write client desconected. Port: %.4d, Client: %.4d\n", this->port, index);
                                printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
                            } else {
                                printf("StreamServer Write EWOULDBLOCK, will try again. Port: %.4d, Client: %.4d\n", this->port, index);
                                tryAgain++;
                            }
                        }
                    }
                    tryAgain = 1;
                }
            }
        }
        this->writeRunning = false;
    } else {
        printf("StreamServer Write, server not running. Port: %.4d\n", this->port);
    }
    printf("StreamServer Write End. Port: %.4d\n", this->port);
    return written;
}

template<class T>
void* StreamServer<T>::HeartBeat(void* arg) {
    StreamServer *self = (StreamServer*) arg;

    self->HeartBeatEvent(arg);
}

template<class T>
void StreamServer<T>::HeartBeatEvent(void* arg) {
    StreamServer *self = (StreamServer*) arg;

    printf("StreamServer Write Init. Port: %.4d\n", self->port);

    unsigned int size = 4;
    char buffer[4] = {'H', 'B', 'H', 'B'};
    unsigned int tryAgain = 1;
    unsigned int totalClients;

    self->hearbeatRunning = true;

    sleep(HEARTBEAT_INTERVAL);

    while (self->running) {
        totalClients = 0;
        for (int index = 0; index <= self->maxFd; ++index) {
            if (index != self->server) {
                if (FD_ISSET(index, &self->masterSet)) {
                    while ((tryAgain > 0) && (tryAgain <= 3)) {
                        int sendRes = send(index, buffer, size, MSG_NOSIGNAL);
                        if (sendRes > -1) {
                            tryAgain = 0;
                            printf("StreamServer HeartBeat sent %.4d bytes. Port: %.4d, Client: %.4d\n", size, self->port, index);
                            totalClients++;
                        } else {
                            if (errno != EWOULDBLOCK) {
                                shutdown(index, SHUT_RDWR);
                                close(index);
                                FD_CLR(index, &self->masterSet);
                                tryAgain = 0;
                                printf("StreamServer HeartBeat client desconected. Port: %.4d, Client: %.4d\n", self->port, index);
                                printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                            } else {
                                printf("StreamServer HeartBeat EWOULDBLOCK, will try again. Port: %.4d, Client: %.4d\n", self->port, index);
                                tryAgain++;
                            }
                        }
                    }
                    tryAgain = 1;
                }
            }
        }
        sleep(HEARTBEAT_INTERVAL);
        printf("StreamServer HeartBeat Sent Complete. Port: %.4d, Total Clients Connected: %.2d\n", self->port, totalClients);
    }

    self->hearbeatRunning = false;

    printf("StreamServer HeartBeat End. Port: %.4d\n", self->port);
}

template<class T>
StreamServer<T>::~StreamServer() {
    StreamServer::running = false;

    printf("StreamServer Closing All Connections. Port: %.4d\n", this->port);
    for (int index = 0; index <= this->maxFd; ++index) {
        if (FD_ISSET(index, &this->masterSet)) {
            shutdown(index, SHUT_RDWR);
            close(index);
            FD_CLR(index, &this->masterSet);
        }
    }

    printf("StreamServer Closing Server. Port: %.4d\n", this->port);
    if (FD_ISSET(this->server, &this->masterSet)) {
        shutdown(this->server, SHUT_RDWR);
        close(this->server);
        FD_CLR(this->server, &this->masterSet);
    }

    printf("StreamServer Closing threads. Port: %.4d\n", this->port);

    pthread_cancel(this->thAcceptClients);
    pthread_cancel(this->thHeartBeat);

    printf("StreamServer Destroy. Port: %.4d\n", this->port);
}