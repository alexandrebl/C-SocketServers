/* 
 * File:   StreamServer.cpp
 * Author: alexandre
 * 
 * Created on 4 de Março de 2014, 09:34
 */

#include "StreamServer.h"

StreamServer::StreamServer(unsigned int Port) {
    struct sockaddr_in serv_addr;
    int optval = 1;
    socklen_t optlen = sizeof(optval);
    
    this->port = Port;    
    this->running = true;
    
    printf("StreamServer Created. Port: %.4d\n", this->port);
    
    server =  socket(AF_INET, SOCK_STREAM, 0);
    
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;  
    serv_addr.sin_addr.s_addr = INADDR_ANY;  
    serv_addr.sin_port = htons(this->port);
    
    if (server < 0){
        printf("StreamServer error opening server socket. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        exit(EXIT_FAILURE);
    }
    
    if(setsockopt(server, SOL_SOCKET, SO_KEEPALIVE, &optval, optlen) < 0) {
        printf("StreamServer error on set keep alive. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        close(server);
        exit(EXIT_FAILURE);
    }
    
    if(setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &optval, optlen) < 0) {
        printf("StreamServer error on set reuse address. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        close(server);
        exit(EXIT_FAILURE);
    }
    
    if (bind(server, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){ 
        printf("StreamServer error on bind. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        close(server);
        exit(EXIT_FAILURE);
    }
     
    if(listen(server,5) < 0){
        printf("StreamServer error on listen. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        close(server);
        exit(EXIT_FAILURE);
    }
    printf("StreamServer on listen. Port: %.4d\n", this->port);
     
    pthread_create(&thAcceptClients, NULL, &AccpetClients, this);
    pthread_detach(thAcceptClients);
}

StreamServer::~StreamServer() {
    this->running = false;
    shutdown(server, SHUT_RDWR);  
    //close(server);
    while(this->acceptRunning) {
        usleep(SLEEP_SLICE);
        puts("Aguardando desconexão");
    }
    printf("StreamServer Destroy. Port: %.4d\n", this->port);
}

void* StreamServer::AccpetClients(void* arg){
    StreamServer *self = (StreamServer*)arg;
    
    struct sockaddr_in cli_addr;
    socklen_t clilen;
    
    printf("StreamServer on AccpetClients. Port: %.4d\n", self->port);
    
    clilen = sizeof(cli_addr);
    
    self->acceptRunning = true;
    while(self->running == true){
        int client = accept(self->server, (struct sockaddr *) &cli_addr, &clilen);
        if (client < 0) {
            printf("StreamServer error on accpet client. Port: %.4d\n", self->port);          
            printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
        }else{
            inet_ntoa(cli_addr.sin_addr);
            printf("StreamServer client connected. Port: %.4d, Client: %.4d\n", self->port, client);          
        }   
    }
    
    self->acceptRunning = false;
    
    printf("StreamServer AccpetClients End. Port: %.4d\n", self->port);
    
    return 0;    
}