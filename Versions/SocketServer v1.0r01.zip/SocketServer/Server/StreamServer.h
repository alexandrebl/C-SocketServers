/* 
 * File:   StreamServer.h
 * Author: alexandre
 *
 * Created on 4 de Março de 2014, 09:34
 */

#ifndef TCPSERVERSOCKET_H
#define	TCPSERVERSOCKET_H

#include <cstdlib>
#include <csignal>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <cerrno>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX_TCP_BUFFER_SIZE     1024
#define MAX_LISTEN_CLIENTS      40
#define SLEEP_SLICE             10000

class StreamServer {
public:
    StreamServer(unsigned int Port);
    virtual ~StreamServer();
private:
    int server;
    unsigned int port;
    bool running;
    
    //Accpent
    bool acceptRunning;
    pthread_t thAcceptClients;
    static void* AccpetClients(void* arg);
};

#endif	/* TCPSERVERSOCKET_H */

