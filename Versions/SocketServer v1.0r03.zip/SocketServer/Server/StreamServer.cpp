/* 
 * File:   StreamServer.cpp
 * Author: Alexandre Brandão Lustosa
 * 
 * Created on 4 de Março de 2014, 09:34
 */

#include "StreamServer.h"

StreamServer::StreamServer(unsigned int Port, unsigned int BufferSize, unsigned int MaxClients) {
    struct sockaddr_in serv_addr;
    int optval = 1;
    socklen_t optlen = sizeof (optval);

    printf("StreamServer Initializade. Port: %.4d\n", this->port);

    this->port = Port;
    this->bufferSize = BufferSize;
    this->maxClients = MaxClients;
    this->maxFd = 0;
    this->running = true;

    server = socket(AF_INET, SOCK_STREAM, 0);

    bzero((char *) &serv_addr, sizeof (serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(this->port);

    if (server < 0) {
        printf("StreamServer error opening server socket. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        exit(EXIT_FAILURE);
    }

    if (setsockopt(server, SOL_SOCKET, SO_KEEPALIVE, &optval, optlen) < 0) {
        printf("StreamServer error on set keep alive. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &optval, optlen) < 0) {
        printf("StreamServer error on set reuse address. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (fcntl(server, F_SETFL, O_NONBLOCK) < 0) {
        printf("StreamServer error on set non block option. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (fcntl(server, F_SETFL, O_ASYNC) < 0) {
        printf("StreamServer error on set async option. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (bind(server, (struct sockaddr *) &serv_addr, sizeof (serv_addr)) < 0) {
        printf("StreamServer error on bind. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }

    if (listen(server, this->maxClients) < 0) {
        printf("StreamServer error on listen. Port: %.4d\n", this->port);
        printf("Socket Port %.4d. Error: %.4d - %s\n", this->port, errno, strerror(errno));
        shutdown(server, SHUT_RDWR);
        close(server);
        exit(EXIT_FAILURE);
    }
    printf("StreamServer on listen. Port: %.4d\n", this->port);

    this->maxFd = this->server;
    FD_ZERO(&this->masterSet);
    FD_SET(this->server, &this->masterSet);

    pthread_create(&thAcceptClients, NULL, &AccpetClients, this);
    pthread_detach(thAcceptClients);

    printf("StreamServer Created. Port: %.4d\n", this->port);
}

void* StreamServer::AccpetClients(void* arg) {
    StreamServer *self = (StreamServer*) arg;

    fd_set acceptSet;
    timeval timeout;
    char buffer[self->bufferSize];

    timeout.tv_usec = 0;
    timeout.tv_sec = SELECT_TIMEOUT;

    memset(buffer, 0, self->bufferSize);

    printf("StreamServer on AccpetClients. Port: %.4d\n", self->port);

    self->acceptRunning = true;

    while (self->running == true) {
        memcpy(&acceptSet, &self->masterSet, sizeof (self->masterSet));

        printf("StreamServer wait on select. Port: %.4d\n", self->port);
        int selectFdCount = select(self->maxFd + 1, &acceptSet, NULL, NULL, &timeout);

        if (selectFdCount < 0) {
            printf("StreamServer error on select. Port: %.4d\n", self->port);
            printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
            break;
        }

        if (selectFdCount == 0) {
            printf("StreamServer timeout on select. Port: %.4d\n", self->port);
            break;
        }

        printf("StreamServer selected succesfully. Port: %.4d, Select Result: %.4d\n", self->port, selectFdCount);
        if (errno > 0) {
            printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
            exit(0);
        }

        for (unsigned int index = 0; index <= self->maxFd && selectFdCount > 0; index++) {
            if (FD_ISSET(index, &acceptSet)) {
                selectFdCount -= 1;

                if (index == self->server) {
                    printf("StreamServer ready for accept incoming connections. Port: %.4d\n", self->port);
                    int newClient = accept(self->server, NULL, NULL);
                    if (newClient < 0) {
                        if (errno != EWOULDBLOCK) {
                            printf("StreamServer error on accept. Port: %.4d\n", self->port);
                            printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                            self->running = false;
                            break;
                        }
                    } else {
                        FD_SET(newClient, &self->masterSet);
                        if (newClient > self->maxFd) self->maxFd = newClient;
                        printf("StreamServer client accepted. Port: %.4d, Client: %.4d\n", self->port, newClient);
                    }
                    printf("StreamServer end for accept incoming connections. Port: %.4d\n", self->port);
                } else {
                    if (self->running == true) {
                        int size = recv(index, buffer, self->bufferSize, 0);

                        if (size < 0) {
                            if (errno != EWOULDBLOCK) {
                                shutdown(index, SHUT_RDWR);
                                close(index);
                                FD_CLR(index, &self->masterSet);
                                printf("StreamServer error, client desconected. Port: %.4d, Client: %.4d\n", self->port, index);
                                printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                            }
                            break;
                        }

                        if (size == 0) {
                            shutdown(index, SHUT_RDWR);
                            close(index);
                            FD_CLR(index, &self->masterSet);
                            printf("StreamServer client desconected. Port: %.4d, Client: %.4d\n", self->port, index);
                            printf("Socket Port %.4d. Error: %.4d - %s\n", self->port, errno, strerror(errno));
                        }
                        printf("StreamServer received %.4d bytes. Port: %.4d, Client: %.4d\n", size, self->port, index);
                    }
                }
            }
        }
    }

    printf("StreamServer Clossing All Connections. Port: %.4d\n", self->port);
    for (int index = 0; index <= self->maxFd; ++index) {
        if (FD_ISSET(index, &self->masterSet)) {
            shutdown(index, SHUT_RDWR);
            close(index);
            FD_CLR(index, &self->masterSet);
        }
    }

    printf("StreamServer Clossing Server. Port: %.4d\n", self->port);
    shutdown(self->server, SHUT_RDWR);
    close(self->server);

    self->acceptRunning = false;

    printf("StreamServer AcceptClients End. Port: %.4d\n", self->port);

    return 0;
}

StreamServer::~StreamServer() {
    this->running = false;
    shutdown(server, SHUT_RDWR);
    //close(server);
    while (this->acceptRunning) {
        usleep(SLEEP_SLICE);
        puts("Aguardando desconexão");
    }
    printf("StreamServer Destroy. Port: %.4d\n", this->port);
}