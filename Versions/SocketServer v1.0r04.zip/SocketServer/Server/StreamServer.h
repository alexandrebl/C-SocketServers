/* 
 * File:   StreamServer.h
 * Author: alexandre
 *
 * Created on 4 de Março de 2014, 09:34
 */

#ifndef TCPSERVERSOCKET_H
#define	TCPSERVERSOCKET_H

#include <cstdlib>
#include <csignal>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <cerrno>
#include <sys/types.h> 
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>

#define SLEEP_SLICE          10000 // Milisegundos
#define SELECT_TIMEOUT       20    // Segundos  
#define LOOPBACK_TEST        

class StreamServer {
public:
    StreamServer(unsigned int Port, unsigned int BufferSize = 8196, 
        unsigned int MaxClients = 40, unsigned int TimeOut = 0);
    virtual ~StreamServer();
    int Write(char *buffer, unsigned int size);
private:
    int server;
    unsigned int port;
    bool running;
    unsigned int bufferSize;
    unsigned int maxClients;
    unsigned int maxFd;
    unsigned int timeout;
    fd_set masterSet;
    
    //Accept and Read
    bool acceptRunning;
    pthread_t thAcceptClients;
    static void* AccpetClients(void* arg);
};

#endif	/* TCPSERVERSOCKET_H */

